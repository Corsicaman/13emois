// static posts Vue component
    Vue.component('liste-destinations', {

        // setting the template that this component will use to render
        template: '#liste-destinations-template',

        // the data function is where we define all the variables this component will need
        // in this specific case, we only need to worry about an array of posts
        data: () => ({
            destinations: []
        }),

        // this is called whenever this component is mounted onto the DOM
        // basically whenever we want to show all the destinations, we go and get them
        mounted() {
            this.getDestinations();
        },

        // this is where you define all the methods this component needs
        methods: {

            // getPost simply sets the 'destinations' variable with static data
            getDestinations() {
                this.destinations = [
                    {
                        "title": "The first post title!"
                    },
                    {
                        "title": "The second post title!"
                    },
                    {
                        "title": "The third post title!"
                    }
                ];
            }
        }
    });

    // Create new Vue instance and mount onto elmement with id app
    new Vue({
        el: '#app'
    });
